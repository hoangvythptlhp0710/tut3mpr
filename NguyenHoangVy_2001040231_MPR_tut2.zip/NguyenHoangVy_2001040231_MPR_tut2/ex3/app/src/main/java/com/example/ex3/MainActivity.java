package com.example.ex3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText input;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        input = findViewById(R.id.editTextNumber2);
        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(v -> {
            Double num = Double.parseDouble(input.getText().toString());
            Double res = num * 24000;
            Toast.makeText(MainActivity.this, "Result: " + res.toString(), Toast.LENGTH_LONG).show();
        });
    }
}