package tut01;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Ex4 {
    public static String maxMin(String inp){
        String[] arr = inp.split(" ");
        int[] listNum = new int[arr.length];
        for (int i = 0; i < listNum.length; i++){
            int num = Integer.parseInt(arr[i]);
            listNum[i] = num;
        }
        int min = listNum[0];
        int max = listNum[0];
        for (int j = 0; j < listNum.length; j++){
            if (listNum[j] > max){
                max = listNum[j];
            }
            if ((listNum[j]<min)){
                min = listNum[j];
            }
        }
        String highest = String.valueOf(max);
        String lowest = String.valueOf(min);
        String outp = highest + " " + lowest;
        return outp;
    }

    @Test
    public void testMaxMin(){
        Ex4 e = new Ex4();
        assertEquals("9 2", e.maxMin("4 8 9 2 5 3"));
    }
}
