package tut01;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Ex1 {
    public static int squareDigit(int num){
        if (num < 10){
            return num*num;
        }
        String output = "";
        while (num > 0){
            int mode = num % 10;
            num = num/10;
            int square = mode * mode;
            String sq = Integer.toString(square);
            output = sq + output;
        }
        int result  = Integer.parseInt(output);
        return result;
    }
    @Test
    public void TestEx1(){
        Ex1 e = new Ex1();
        assertEquals(811181, e.squareDigit(9119));
    }
}
