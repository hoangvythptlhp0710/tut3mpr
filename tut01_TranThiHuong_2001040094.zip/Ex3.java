package tut01;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Ex3 {
    public static double countFare(double totalKm){
        int tax = 15000;
        double fare;
        if (totalKm <= 1){
            fare = tax * totalKm;
        }
        else if (totalKm <=10){
            fare = 15000 + (totalKm -1) * 12000;
        }
        else if (totalKm <= 100){
            fare = 15000 + 9 * 12000;
            double rest = totalKm - 10;
            double loopTimes = rest/10 ;
            double mode = rest% 10;
            int tax2 = 11000;
            for (int i = 1; i <= loopTimes; i++){
                fare = fare + tax2*10;
                tax2 = tax2 - 500;


            }
            fare = fare + mode * tax2;

        } else {
            double tenFirst =  1 * 15000 + 9 * 12000;
            double ninety = 0;
            int tax2 = 11000;
            for (int j = 1; j <= 9; j++){
                ninety =  ninety + tax2 * 10;
                tax2 = tax2 - 500;
            }
            double rest = (totalKm - 100)*7000;
            fare = tenFirst + ninety + rest;
        }
        if (fare < 10000){
            return 10000;
        }else {
            return fare;
        }
    }
    @Test
    public void testFare(){
        Ex3 e = new Ex3();
        assertEquals(10000, e.countFare(0.5));
        assertEquals(15000, e.countFare(1));
        assertEquals(99000, e.countFare(8));
        assertEquals(623000, e.countFare(60));
        assertEquals(961000, e.countFare(104));
    }
}
