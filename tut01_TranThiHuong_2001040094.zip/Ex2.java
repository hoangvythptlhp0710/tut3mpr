package tut01;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class Ex2 {
    public static double Accounting (double expectedPrice) {
        double pre_tax;
        if (expectedPrice < 100){
            pre_tax = expectedPrice*100/105;
        } else {
            pre_tax = expectedPrice*100/110;
        }

        double pretax = Math.floor(pre_tax * 100.0)/100;
        return pretax;
    }

    @Test
    public void testAccount(){
        Ex2 e = new Ex2();
        assertEquals(11.42, e.Accounting(12));
    }
}
