package com.example.myanim;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Game extends AppCompatActivity {
    private  ImageView character;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        ImageButton imgBtnBall = findViewById(R.id.imgBtnBall);
        Button btnSpin = findViewById(R.id.btnSpin);
        ImageButton imgBtnStar = findViewById(R.id.imgBtnStar);
        Button btnJump= findViewById(R.id.btnJump);
        Button btnTurnAround = findViewById(R.id.btnTurnAround);
        ImageView imgStar = findViewById(R.id.imgStar);
        ImageView imgBall = findViewById(R.id.imgBall);

        if(imgStar.getAlpha() == 0){
            character = imgBall;
        }else character = imgStar;

        imgBtnStar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgBall.animate().alpha(0).setDuration(1000);
                imgStar.animate().alpha(1).setDuration(1000);
                character = imgStar;
            }
        });

        imgBtnBall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                imgStar.animate().alpha(0).setDuration(1000);
                imgBall.animate().alpha(1).setDuration(1000);
                character = imgBall;
            }
        });

        btnJump.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                character.animate().translationYBy(-500f).setDuration(1000).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        character.animate().translationYBy(500f).setDuration(1000).withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                character.animate().translationY(0).setDuration(1000);
                            }
                        });;
                    }
                });
            }
        });

        btnSpin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                character.animate().rotationBy(360*2).setDuration(1000).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        character.animate().translationY(0).setDuration(1000).withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                character.animate().rotation(0).setDuration(1000);
                            }
                        });
                    }
                });;
            }
        });

        btnTurnAround.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                character.animate().rotationYBy(360).setDuration(1000).withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        character.animate().rotationY(0).setDuration(1000);
                    }
                });
            }
        });

        Button btnClap = findViewById(R.id.btnClap);
        btnClap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MediaPlayer mediaPlayer = MediaPlayer.create(Game.this, R.raw.clapping);
                mediaPlayer.start();
            }
        });
    }
}